const Footer = ()=>{
    return(
        <footer class="text-center">
            <div class="text-center p-3">
                © 2021 Copyright : Shwetha Shetty               
            </div>
        </footer>
    )
}

export default Footer